README.TXT
Leanne Lestak, 7/16/2013

This directory contains materials explaining how to do a "Quick and Dirty" conversion from ArcGIS vs 9.3 FGDC metadata to EML vs 2.1 metadata.

Read the Quick_dirty_convert_FGDC_9.3_to_EML_vs_2.1.docx first. The "raster" and "vector" directories contain sample input FGDC metadata, companion output EML vs 2.1 metadata and the FGDC text format metadata.